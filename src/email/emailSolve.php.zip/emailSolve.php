<?php
require_once("phpmailer/class.phpmailer.php");

$mail=new PHPMailer();

$mail->IsSMTP();                   //Important b'coz by this stmt we sent mail using smtp
$mail->SMTPAuth = true;       // enable SMTP authentication
$mail->SMTPSecure = "ssl";  // sets the prefix to the servier
$mail->Host = "smtp.gmail.com"; // sets GMAIL as the SMTP server
$mail->Port = 465; // set the SMTP port for the GMAIL server
$mail->Username = "clauciozitha@gmail.com"; // GMAIL username
$mail->Password = "clauciozithayrd"; // GMAIL password

$mail->FromName = "Claucio Zitha";
$mail->From = "clauciozitha@gmail.com";
$mail->AddAddress("claucioentreter@gmail.com","Claucio Zitha");
$mail->Subject = "Assunto";

$mail->Body ="body of the message";
$result=$mail->Send();
    return $result;
    ?>