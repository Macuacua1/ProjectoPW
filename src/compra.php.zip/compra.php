<?php
	session_start();
	include_once"../config/conexao.php";
	if(isset($_SESSION['carrinho'])){


	}else{
		if (isset($_GET['id'])) {
			# code...
			
			$nome='';
			$quant=0;
			$preco=0;
			$caption='';

			$con=new conexao();

	        $sql = 'select * from foto where cod_foto='.$_GET['id']; 
	        $result=$con->query($sql);//($sql);
	        if ($result->num_rows>0) {
		          while ($f=$result->fetch_assoc()) {
		          	$nome=$f['nome'];
		          	$caption=$f['caption'];

		          }
		          $carregar=array('id' =>$_GET['id'],
		          					'nome'=>$nome,
		          					'Cnption'=>$caption
		          				 );
		          $_SESSION['carrinho']=$carregar;
			}
		
		    }
		}
        
    // $cod_foto=$_GET["id"];
    $conexao=null;

?>
<!DOCTYPE html>
<html>
<head>
	<title>Carrinho</title>
	<link rel="stylesheet" type="text/css" href="../lib/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="../lib/css/custom.css">
</head>
<body>
	<div class="navbar navbar-default navbar-inverse navbar-static-top" height="20">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbar-ex-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="Locacao images\hermes-logo-small.png"><span>Isis Arte</span></a>
                </div>
                <div class="collapse navbar-collapse" id="navbar-ex-collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li class="active">
                            <a href="home.html">Home</a>
                        </li>
                        <li>
                            <a href="produtos.html">Produtos</a>
                        </li>
                        <li>
                            <a href="eventos.html">Eventos</a>
                        </li>
                        <li>
                            <a href="carrinho.html">Carrinho</a>
                        </li>
                        <li>
                            <a href="curiosidades.html">Perguntas Frequentes</a>
                        </li>
                        <li>
                            <a href="sobre.html">Sobre</a>
                        </li>
                        <li>
                            <a href="contaco.html">Contactos</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <section>
        	<?php
        		$total=0;
        		if(isset($_SESSION['carrinho'])){
        			$dados=$_SESSION['carrinho'];
        			// for ($i=0; $i <count($dados) ; $i++) { 
        			foreach ($dados as $i) {
        				# code...
        			
        			?>
        			<div class="thumbnail">
        				<center>
        					<?php echo "<img src=../Imagens/$dados[$i]['nome']>";?> <!--$row[nome]--> 
        					<span>	<?php $dados [$i]['caption'];?></span><br>
        					<!-- futura quantidade e preco -->
        				</center>
        			</div>	
					<?php 
						//$total=$dados[$i]['quant']*$dados[$i]['quant']+$total;  

						$total=$i+$total;//para testes
        			}

        		}else
        			{
        				echo "<center><h2>Carrinho Vazio</h2></center>";

        			}


        		echo "<center><h2>Total:".$total."</h2></center>";

        	?>
        </section>
	<!-- <?php// $con=new conexao();

             //   $sql = 'select * from foto';
               // $result=$con->query($sql);//($sql);
              //if ($result->num_rows>0) {

               // while ($f=$result->fetch_assoc()) {
                ?> -->


</body>
</html>